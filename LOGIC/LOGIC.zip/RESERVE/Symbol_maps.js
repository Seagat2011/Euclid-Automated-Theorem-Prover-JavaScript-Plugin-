// 5 spacers per Capitalized letter
// 4 spacers elsewise
symbol_maps = {
'noteq':'&ne;',
'le':'&le;',
}